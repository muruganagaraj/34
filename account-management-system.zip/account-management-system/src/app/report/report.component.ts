import { Component, OnInit } from '@angular/core';
import { AddGstComponent } from 'app/add-gst/add-gst.component';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { ConfirmationDialogService } from '../confirmaion-dialog/confirmation-dialog.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { reportModel, expensiveList } from 'app/report/report.component.viewmodel';

export interface TextValuePair {
  key?: string;
  value?: string;
}

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  reportForm: FormGroup;
  maxDate = new Date();
  buyerList: TextValuePair[];
  typeList: TextValuePair[];
  reportList: reportModel[] = [];
  reportDownloadForm: FormGroup;
//   dataSource = ELEMENT_DATA;
//   columnsToDisplay = ['name', 'weight', 'symbol', 'position'];
//   expandedElement: PeriodicElement;
  constructor() { }

  ngOnInit() {
    this.reportForm = new FormGroup({
      startDate: new FormControl(null, [Validators.required]),
      endDate: new FormControl(null, [Validators.required]),
      buyerValue: new FormControl(null, []),
    });
    this.reportDownloadForm = new FormGroup({
      downloadType: new FormControl(null, [Validators.required])
    })
    this.buyerList = [
      { key:'ADP01', value: 'Aditya Birla'},
      { key:'INFO01', value: 'Infosys'},
      { key:'WIP01', value: 'Wipro'}
    ];
    this.typeList = [
      { key:'EXCEL', value: 'Excel' },
      { key:'PDF', value: 'PDF' }
    ];
  }

  onShowClick(): void {
    const request: {} = {
      startDate: this.reportForm.controls['startDate'].value,
      endDate: this.reportForm.controls['endDate'].value,
      buyerValue: this.reportForm.controls['buyerValue'].value
    }
    console.log(request);
    // call the service with above request
    this.reportList = [{
        buyername : 'BUY01',
        expensivedate: new Date(),
        totalamount: '100',
        gst: 100,
        isgstrequired: true,
        gstpercentage: 25,
        discount: 10,
        finalamount: 2000,
        items: [{
            itemcode: 'item01',
            itemname: 'itemname1',
            quantity: 10,
            amount: 100
        },{
            itemcode: 'item01',
            itemname: 'itemname1',
            quantity: 10,
            amount: 100
        },{
            itemcode: 'item01',
            itemname: 'itemname1',
            quantity: 10,
            amount: 100
        }]
    },
    {
        buyername : 'BUY01',
        expensivedate: new Date(),
        totalamount: '100',
        gst: 100,
        isgstrequired: true,
        gstpercentage: 25,
        discount: 10,
        finalamount: 2000,
        items: [{
            itemcode: 'item01',
            itemname: 'itemname1',
            quantity: 10,
            amount: 100
        }]
    }];
  }

  onDownloadClick() {
    // call report service to get the file format.
    console.log(this.reportDownloadForm.controls['downloadType'].value);
  }
 
}
  

