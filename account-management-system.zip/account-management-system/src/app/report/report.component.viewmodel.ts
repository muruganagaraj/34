
export interface reportModel {
    buyername: string;
    expensivedate: Date;
    totalamount: string;
    gst: number;
    isgstrequired: boolean;
    gstpercentage: number;
    discount: number;
    finalamount: number;
    items: expensiveList[];
}
export interface expensiveList {
    itemcode: string;
    itemname: string;
    quantity: number;
    amount: number;
}