interface TextValuePair<TValue> {
    text: string;
    value: TValue;
}
declare type TextPair = TextValuePair<string>;
